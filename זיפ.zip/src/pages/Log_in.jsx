import React from 'react'

export default function Log_in() {
  

  return (
    <div className='container mg-3'>
      <h1 className='line'> log in </h1>

      <div className='container'>

        <strong>user name:</strong> <br />
        <input type="text" name="name"></input> <br/>
        <strong>password:</strong> <br />
        <input type="password" name="password"></input> <br/> <br/>

        {/* <input type="button" name="log in"></input> */}
        <button>log in</button>
      </div>

    </div>

    
  );
}
