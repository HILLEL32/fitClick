import React, { useState } from 'react';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { collection, addDoc } from 'firebase/firestore';
import {auth, db} from '../fireBase/firebase'

export default function Sign_up() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = async () => {
    e.preventDefault();

    // בדיקה בסיסית לסיסמה
    if (password.length < 6) {
      setMessage('הסיסמה צריכה להיות לפחות באורך 6 תווים');
      return;
    }

    try {
      // יצירת המשתמש באימות
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      // הוספת פרטי המשתמש למסד הנתונים
      await addDoc(collection(db, 'users'), {
        uid: user.uid,
        email,
        username,
        phone
      });

      setMessage('ההרשמה הצליחה!');
      // איפוס הטופס
      setEmail('');
      setPassword('');
      setUsername('');
      setPhone('');
    } catch (error) {
      setMessage('שגיאה: ' + error.message);
    }
  };

  return (
    <div className='container'>
      <h1 className='line'>Sign Up</h1>

      <form onSubmit={handleSubmit}>
        <strong>User name:</strong><br />
        <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} /><br />

        <strong>Password:</strong><br />
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} /><br />

        <strong>Email:</strong><br />
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} /><br />

        <strong>Phone number:</strong><br />
        <input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} /><br /><br />

        <button type="submit">Send</button>
        <p>{message}</p>
      </form>
    </div>
  );
}
