import { Link } from 'react-router-dom';
import '../css/design.css'


export default function Home() {
  return (
    <div className='container'>
      <h5>wellcome to </h5>
      <h1 className='line'>fitClick</h1>
      <Link to="/log_in" className='btn btn-success btn-lg mt-3 me-5'> log in </Link> 
      <Link to="/sign_up" className='btn btn-success btn-lg mt-3 '> sign up </Link> 
      
      
    </div>
  )
}
