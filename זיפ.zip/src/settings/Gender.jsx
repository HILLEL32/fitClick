import React from 'react'
import 
export default function Gender() {
  return (
    <div>choose your gender</div>
    
  )
}
