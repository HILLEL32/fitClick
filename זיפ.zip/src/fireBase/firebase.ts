import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBxWr5G4nXGLHin4JAy0sH26hWcMCHqwIQ",
  authDomain: "fitclick2-a86fe.firebaseapp.com",
  projectId: "fitclick2-a86fe",
  storageBucket: "fitclick2-a86fe.firebasestorage.app",
  messagingSenderId: "901916011617",
  appId: "1:901916011617:web:28c9e64c9fd7278dcd4e20"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);