
import './App.css'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Header from './component/Header'
import Home from './pages/Home'
import Log_in from './pages/Log_in'
import Sign_up from './pages/Sign_up'
import AppContextProvider from './context/AppContext'
import { ToastContainer } from 'react-toastify'


function App() {

  return (
    <AppContextProvider>
      
      <ToastContainer theme='colored' autoClose={10000} /> 
      <BrowserRouter>
        <Header />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/log_in" element={<Log_in />} />
          <Route path="/sign_up" element={<Sign_up />} />

        </Routes>

      </BrowserRouter>
    </AppContextProvider>
  )
}

export default App
